package com.giitSolutions.project.Service;

import com.giitSolutions.project.entities.Book;

import java.util.List;

public interface BookService {
    public Book getBookByID(Integer id);
    public Book saveBook(Book book);
    public List<Book> getBooks();
    public Book updateBookById(Integer id, Book updateBook);
    public void deleteBookById(Integer id);
}
