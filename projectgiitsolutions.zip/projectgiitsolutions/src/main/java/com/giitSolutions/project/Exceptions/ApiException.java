package com.giitSolutions.project.Exceptions;

import org.springframework.http.HttpStatus;

import java.time.ZonedDateTime;

public class ApiException {
    private final String messsage;
    private final HttpStatus httpStatus;
    private final ZonedDateTime timeStamp;

    public ApiException(String messsage, HttpStatus httpStatus, ZonedDateTime timeStamp) {
        this.messsage = messsage;
        this.httpStatus = httpStatus;
        this.timeStamp = timeStamp;
    }

    public String getMesssage() {
        return messsage;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public ZonedDateTime getTimeStamp() {
        return timeStamp;
    }
}
