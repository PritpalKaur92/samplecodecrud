package com.giitSolutions.project.Service;

import com.giitSolutions.project.Dao.BookDao;
import com.giitSolutions.project.entities.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class BookServiceImpl implements BookService{

    private BookDao bookDao;

    @Autowired
    public BookServiceImpl(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    @Override
    public Book getBookByID(Integer id) { return bookDao.findById(id).get(); }

    @Override
    public Book saveBook(Book book) { return bookDao.save(book); }

    @Override
    public List<Book> getBooks() { return bookDao.findAll(); }

    @Override
    public Book updateBookById(Integer id, Book bookToBeUpdated) {
        Book book = this.getBookByID(id);
        book.setName(bookToBeUpdated.getName());
        book.setAuthor(bookToBeUpdated.getAuthor());
        return bookDao.save(book);
    }

    @Override
    public void deleteBookById(Integer id) { bookDao.delete(getBookByID(id)); }
}
