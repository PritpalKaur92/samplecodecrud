package com.giitSolutions.project.DTO;


public class BookDTO {
    private Integer id;
    private String name;
    private AuthorDTO authorDTO;

    public BookDTO(Integer id, String name, AuthorDTO authorDTO) {
        this.id = id;
        this.name = name;
        this.authorDTO = authorDTO;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public AuthorDTO getAuthorDTO() {
        return authorDTO;
    }

    public void setAuthorDTO(AuthorDTO authorDTO) {
        this.authorDTO = authorDTO;
    }
}
