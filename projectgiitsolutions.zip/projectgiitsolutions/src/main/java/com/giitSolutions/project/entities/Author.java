package com.giitSolutions.project.entities;

import javax.persistence.*;

@Entity
@Table(name = "author")
public class Author {
    @Id
    @Column(name = "book_id")
    private Long id;

    @Column
    private String authorName;

    @OneToOne(mappedBy = "author")
    private Book book;

    public Author(Long id, String authorName, Book book) {
        this.id = id;
        this.authorName = authorName;
        this.book = book;
    }

    public Author() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }
}
