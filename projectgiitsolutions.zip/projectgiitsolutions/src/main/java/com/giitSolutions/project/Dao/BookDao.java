package com.giitSolutions.project.Dao;

import com.giitSolutions.project.entities.Book;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BookDao extends JpaRepository<Book,Integer> {

}
