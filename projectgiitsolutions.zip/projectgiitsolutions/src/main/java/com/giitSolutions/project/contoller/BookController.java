package com.giitSolutions.project.contoller;

import com.giitSolutions.project.DTO.BookDTO;
import com.giitSolutions.project.Exceptions.ApiRequestException;
import com.giitSolutions.project.Service.BookService;
import com.giitSolutions.project.entities.Book;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value="/api/v1")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private ModelMapper modelMapper;

    @PostMapping(value="/book")
    public ResponseEntity<BookDTO> addBook(@RequestBody BookDTO bookDTO ){

        try{
            Book book = modelMapper.map(bookDTO, Book.class);
            Book savedBook = bookService.saveBook(book);
            BookDTO savedBookDTO = modelMapper.map(savedBook, BookDTO.class);
            return new ResponseEntity<BookDTO>(savedBookDTO, HttpStatus.CREATED);
        }catch(Exception e){
            throw new ApiRequestException("Ooops invalid request. Please check!!");
        }
    }


    @GetMapping(value = "/book/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookDTO> getBookById(@PathVariable(value = "id") Integer id) {
       try {
           Book book = bookService.getBookByID(id);
           BookDTO response = modelMapper.map(book, BookDTO.class);
           return new ResponseEntity<>(response, HttpStatus.OK);
       }catch(Exception e){
           throw new ApiRequestException("Your request is invalid");
       }
    }

    @GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getAllBooks() {
        try {
            List<Book> booksList = new ArrayList<Book>();
            booksList = bookService.getBooks();
            List<BookDTO> bookDTOList = new ArrayList<>();
            for(Book book : booksList){
                bookDTOList.add(modelMapper.map(book,BookDTO.class));
            }
            return new ResponseEntity<>(bookDTOList, HttpStatus.OK);
        } catch(Exception e){
            throw new ApiRequestException("Your request cannot be processed!!");
        }
    }

    @PutMapping(value = "/book/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<BookDTO> updateBookById(@PathVariable(value = "id") Integer id, @RequestBody BookDTO bookDTO) {

        try {
            Book book = modelMapper.map(bookDTO, Book.class);
            Book updatedBook = bookService.updateBookById(id, book);
            BookDTO updatedBookDTO = modelMapper.map(updatedBook, BookDTO.class);
            return new ResponseEntity<BookDTO>(updatedBookDTO, HttpStatus.OK);
        }catch (Exception e){
            throw new ApiRequestException("Oops book can not be updated. Please try again!!");
        }
    }

    @DeleteMapping(value = "/book/{id}")
    public ResponseEntity<Object> deleteBookById(@PathVariable(value = "id") Integer id) {
        try {
            bookService.deleteBookById(id);
            return new ResponseEntity<>("Deleted", HttpStatus.OK);
        } catch(Exception e){
            throw new ApiRequestException("Ooops invalid request. Cannot be deleted");
    }
}
}
